function visibility(mostrar, ocultar) {
  document.getElementById(ocultar).classList.add('oculta');
  document.getElementById(mostrar).classList.remove('oculta');
}